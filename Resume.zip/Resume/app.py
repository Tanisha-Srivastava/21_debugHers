from flask import Flask, render_template, request, jsonify
import docx
import re
from collections import Counter
from rapidfuzz import fuzz
from nltk.corpus import stopwords
from sklearn.feature_extraction.text import CountVectorizer

app = Flask(__name__)

# NLTK stopwords setup
stop_words = set(stopwords.words("english"))

# Function to extract text from docx
def extract_text_from_docx(docx_path):
    doc = docx.Document(docx_path)
    text = "\n".join([para.text for para in doc.paragraphs])
    return text.lower()

# Function to extract resume details
def extract_resume_details(text):
    details = {}
    lines = text.split("\n")
    details["Name"] = lines[0].strip()

    # Extract Email
    email_pattern = r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}"
    email_match = re.search(email_pattern, text)
    details["Email"] = email_match.group(0) if email_match else "Not Found"

    # Extract Phone Number
    phone_pattern = r"\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}"
    phone_match = re.search(phone_pattern, text)
    details["Phone"] = phone_match.group(0) if phone_match else "Not Found"

    # Extract Skills (Filtered)
    skill_keywords = ["python", "java", "c++", "javascript", "html", "css", "react", "node.js"]
    extracted_skills = [word for word in skill_keywords if word in text]
    details["Skills"] = extracted_skills

    # Extract Years of Experience
    exp_pattern = r"(\d+)\+?\s*years?\s*of\s*experience"
    exp_match = re.search(exp_pattern, text)
    details["Years of Experience"] = int(exp_match.group(1)) if exp_match else 0

    # Extract Education
    education_pattern = r"(bachelor’s degree|master’s degree|phd|diploma) in (.*?)\s*(?:\n|,)?\s*(.*?)\s*(\d{4})"
    education_match = re.search(education_pattern, text, re.IGNORECASE)
    if education_match:
        details["Education"] = {
            "Degree": education_match.group(1),
            "Field": education_match.group(2),
            "University": education_match.group(3),
            "Year": education_match.group(4),
        }
    else:
        details["Education"] = "Not Found"

    return details

# Predefined job descriptions for multiple roles
job_descriptions = {
    "Software Developer": "We are looking for a Software Developer proficient in Python, Java...",
    "Web Developer": "Seeking a Web Developer skilled in JavaScript, React, Node.js...",
}

# Identify the best-matching role
def identify_best_matching_role(resume_text, job_descriptions):
    best_match = None
    highest_score = 0
    for role, description in job_descriptions.items():
        match_score = fuzz.ratio(resume_text, description)
        if match_score > highest_score:
            highest_score = match_score
            best_match = role
    return best_match

# Compute ATS score based on best-matching role
def compute_ats_score(resume_text, job_description):
    resume_words = [word.lower() for word in resume_text.split() if word.lower() not in stop_words]
    job_words = [word.lower() for word in job_description.split() if word.lower() not in stop_words]

    vectorizer = CountVectorizer(ngram_range=(1, 2)).fit([" ".join(job_words)])
    resume_ngrams = vectorizer.transform([" ".join(resume_words)]).toarray()[0]
    job_ngrams = vectorizer.transform([" ".join(job_words)]).toarray()[0]

    similarity_score = fuzz.ratio(" ".join(resume_words), " ".join(job_words))

    match_score = sum(min(r, j) for r, j in zip(resume_ngrams, job_ngrams)) / sum(job_ngrams) * 100
    final_score = round((match_score + similarity_score) / 2, 2)

    return final_score+30

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload_resume():
    if 'resume' not in request.files:
        return jsonify({'error': 'No file part'})
    
    file = request.files['resume']
    if file.filename == '':
        return jsonify({'error': 'No selected file'})
    
    resume_text = extract_text_from_docx(file)
    resume_details = extract_resume_details(resume_text)

    best_matching_role = identify_best_matching_role(resume_text, job_descriptions)
    selected_job_description = job_descriptions.get(best_matching_role, "")

    ats_score = compute_ats_score(resume_text, selected_job_description)
    
    return jsonify({
        'resume_details': resume_details,
        'best_matching_role': best_matching_role,
        'ats_score': ats_score
    })

if __name__ == '__main__':
    app.run(debug=True)

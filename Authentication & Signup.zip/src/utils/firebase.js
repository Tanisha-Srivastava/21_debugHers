import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyCVAJ2_XusBg_jicUhhWVAUChpaB2OIRII",
  authDomain: "secondsprint-70c01.firebaseapp.com",
  projectId: "secondsprint-70c01",
  storageBucket: "secondsprint-70c01.firebasestorage.app",
  messagingSenderId: "418482212182",
  appId: "1:418482212182:web:e1a19cb74a71e9788d1af7",
  measurementId: "G-P8N4DYWM72"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);

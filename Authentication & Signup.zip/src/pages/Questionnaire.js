import React, { useState } from "react";
import "./Questionnaire.css";  // ✅ Import the CSS file

const Questionnaire = () => {
  const [formData, setFormData] = useState({
    jobRole: "Software Developer",
    experience: 0,
    skills: "",
    careerBreak: "Less than 6 months",
    childcare: "No",
    childcareNeeds: "",
    workPreference: "Remote",
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.id]: e.target.value });
  };

  const saveToJson = () => {
    const jsonData = JSON.stringify(formData, null, 2);
    const blob = new Blob([jsonData], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "job_data.json";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  return (
    <div className="questionnaire-container">  
      <div className="questionnaire-box">
        <h2>Job Matching Questionnaire</h2>

        <form>
          <label>Preferred Job Role</label>
          <select id="jobRole" value={formData.jobRole} onChange={handleChange}>
            <option>Software Developer</option>
            <option>Web Developer</option>
            <option>Data Analyst</option>
            <option>DevOps Engineer</option>
            <option>Cybersecurity Analyst</option>
            <option>Other</option>
          </select>

          <label>Years of Experience</label>
          <input
            type="number"
            id="experience"
            value={formData.experience}
            onChange={handleChange}
            min="0"
            max="20"
          />

          <label>Technical Skills (comma-separated)</label>
          <input
            type="text"
            id="skills"
            value={formData.skills}
            onChange={handleChange}
            placeholder="Python, Java, SQL"
          />

          <label>Duration of Career Break</label>
          <select id="careerBreak" value={formData.careerBreak} onChange={handleChange}>
            <option>Less than 6 months</option>
            <option>6 months - 1 year</option>
            <option>1 - 2 years</option>
            <option>2 - 5 years</option>
            <option>More than 5 years</option>
          </select>

          <label>Do you require childcare support?</label>
          <select id="childcare" value={formData.childcare} onChange={handleChange}>
            <option value="No">No</option>
            <option value="Yes">Yes</option>
            <option value="Flexible">Open to flexible options</option>
          </select>

          {formData.childcare === "Yes" && (
            <div>
              <label>What kind of childcare support?</label>
              <input
                type="text"
                id="childcareNeeds"
                value={formData.childcareNeeds}
                onChange={handleChange}
                placeholder="E.g., daycare, flexible hours"
              />
            </div>
          )}

          <label>Work Type Preference</label>
          <select id="workPreference" value={formData.workPreference} onChange={handleChange}>
            <option>Remote</option>
            <option>Hybrid</option>
            <option>On-site</option>
            <option>Flexible hours</option>
          </select>

          <button type="button" onClick={saveToJson} className="save-button">
            Save as JSON
          </button>
        </form>
      </div>
    </div>
  );
};

export default Questionnaire;
